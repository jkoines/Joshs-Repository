"""Data related utility functions."""

__author__ = ["", ""]

from csv import DictReader


def get_keys(
    input_dict: (
        dict[str, list[str]]
        | dict[str, list[int]]
        | dict[str, list[str | int]]
        | dict[str, int]
        | dict[str, str]
    ),
) -> list[str]:
    result: list[str] = []
    for key in input_dict:
        result.append(key)

    return result


def convert_columns_to_int(
    data: dict[str, list[str]], columns_conv: list[str]
) -> dict[str, list[str | int]]:
    """Convert the data in the selected columns to be of type int."""
    # Create new table to store converted data
    data_converted: dict[str, list[int | str]] = {}

    # Iterate through column names (keys of the dictionary)
    for col_name in data:
        # Create new list to append converted values to
        data_converted[col_name] = []

        # Declare the converted value with a type of either int or str
        converted_value: int | str

        # Iterate through data values in the column
        for value in data[col_name]:
            # If this column is in the list of columns to be converted,
            # cast it to an int
            if col_name in columns_conv:
                converted_value = int(value)
            else:
                converted_value = value

            # Add it to the new column of values, the list we created
            # that we have a reference to at data_converted[col_name]
            data_converted[col_name].append(converted_value)

    return data_converted


"""These are the functions we wrote/will write in class!"""


def read_csv_rows(filename: str) -> list[dict[str, str]]:
    """Read the rows of a CSV into a 'table'."""
    result: list[dict[str, str]] = []

    # Open a handle to the data file
    file_handle = open(filename, "r", encoding="utf8")

    # Prepare to read the data file as a CSV rather than just strings.
    csv_reader = DictReader(file_handle)

    # Read each row of the CSV line-by-line
    for row in csv_reader:
        result.append(row)

    # Close the file when done, to free its resources.
    file_handle.close()

    return result


def column_values(table: list[dict[str, str]], column: str) -> list[str]:
    """Produce a list[str] of all values in a single column."""
    result: list[str] = []

    for row in table:
        item: str = row[column]
        result.append(item)

    return result


def columnar(row_table: list[dict[str, str]]) -> dict[str, list[str]]:
    """Transform a row-oriented table to a column-oriented table."""
    result: dict[str, list[str]] = {}

    first_row: dict[str, str] = row_table[0]
    for column in first_row:
        result[column] = column_values(row_table, column)

    return result


def head(column_data: dict[str, list[str]], n: int) -> dict[str, list[str]]:
    """produces new column-based table with only n rows of data"""
    result: dict[str, list[str]] = {}
    for column_name in column_data:
        name_list: list[str] = []
        for i in range(n):
            name_list.append(column_data[column_name][i])
        result[column_name] = name_list
    return result


def select(
    column_data: dict[str, list[str]], permitted_columns: list[str]
) -> dict[str, list[str]]:
    """produces new column-based table with only permitted columns"""
    result: dict[str, list[str]] = {}
    for column in permitted_columns:
        result[column] = column_data[column]
    return result


def concat(
    column_data1: dict[str, list[str]], column_data2: dict[str, list[str]]
) -> dict[str, list[str]]:
    """combine two different data into one"""
    result: dict[str, list[str]] = {}
    for column in column_data1:
        result[column] = list(column_data1[column])
    for column in column_data2:
        if column in result:
            for item in column_data2[column]:
                result[column].append(item)
        else:
            result[column] = list(column_data2[column])
    return result


def count(input: list[str]) -> dict[str, int]:
    """determines the frequency of values in a list"""
    result: dict[str, int] = {}
    for element in input:
        if element in result:
            result[element] += 1
        else:
            result[element] = 1
    return result


def filter_value(
    column_data: dict[str, list[str]], column: str, threshold: int, inequality: str
) -> dict[str, list[str]]:
    """Filter out rows where the specified column fails to meet the threshold. inequality can be '>=', '>', '<=', '<', or '=='"""
    result: dict[str, list[str]] = {}

    for col in column_data:
        result[col] = []

    for i in range(len(column_data[column])):
        value: int = int(column_data[column][i])

        # Check if this row passes the threshold
        keep: bool = False
        if inequality == ">=" and value >= threshold:
            keep = True
        elif inequality == ">" and value > threshold:
            keep = True
        elif inequality == "<=" and value <= threshold:
            keep = True
        elif inequality == "<" and value < threshold:
            keep = True
        elif inequality == "==" and value == threshold:
            keep = True

        if keep:
            for col in column_data:
                result[col].append(column_data[col][i])

    return result
